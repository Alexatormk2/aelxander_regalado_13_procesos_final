import java.util.concurrent.Semaphore;

public class Lector  extends Thread {

    private Semaphore semaforo;

    public Lector(String nombre, Semaphore s) {
        super(nombre);
        this.semaforo = s;
    }

    public void run() {

        try {
            semaforo.acquire(1);
            System.out.println(getName() + " :Intentando leer");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try {
            sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        semaforo.release(1);

        System.out.println(getName() + " :ya he leido");
    }
}

