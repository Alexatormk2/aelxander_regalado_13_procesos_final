import java.util.concurrent.Semaphore;

public class Principal {

    public static void main(String args[]) {
        Semaphore s = new Semaphore(10);//un semaforo de 10 recursos
        //acquire(10) = esperará a tener los 10 recursos disponibles y hasta que no tenga los 10 disponibles no hará nada.
        //acquire() = intentará tener un recurso disponible de los diez



        for (int i = 1; i < 4; i++) {
            new Escritor("Escritor" + i, s).start();
        }


        for (int i = 1; i <= 10; i++) {
            new Lector("Lector" + i, s).start();
        }


}}
