import java.util.concurrent.Semaphore;

public class Escritor extends Thread {

    private Semaphore semaforo;

    public Escritor(String nombre, Semaphore s) {
        super(nombre);
        this.semaforo = s;
    }

    public void run() {
        System.out.println(getName() + " : Intentando escribir");

        try {
            semaforo.acquire(10);

        } catch (InterruptedException e) {

        }
        System.out.println(getName() + " : Ya he escrito");
        try {
            sleep(1000);
        } catch (InterruptedException e) {

        }
        semaforo.release(10);


    }
}
