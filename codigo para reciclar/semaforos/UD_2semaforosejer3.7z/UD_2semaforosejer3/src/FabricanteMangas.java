import java.util.concurrent.Semaphore;

public class FabricanteMangas  extends Thread {
    Semaphore cestaMangasCapacidad, cestaMangasCantidad;
    public FabricanteMangas(Semaphore cestaMangas, Semaphore cestaMangasCantidad) {
        this.cestaMangasCapacidad = cestaMangas;
        this.cestaMangasCantidad = cestaMangasCantidad;
    }
    public void run(){
        while (!FabricaJerseis.fin){
            try {
                cestaMangasCapacidad.acquire(2);//Me aseguro de que aun caben mas mangas

                System.out.println ("Fabrico dos mangas");
                cestaMangasCantidad.release(2);//YA pueden usar las mangas que hemos fabricado

            } catch (InterruptedException e) {}
        }
    }
    public void parar() {

        FabricaJerseis.fin = true;






    }

}
