import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.concurrent.*;

public class FabricaJerseis {
    final int CAPACIDADMANGAS = 20;
    final int CAPACIDADCUERPOS = 8;
    static boolean fin;
    Semaphore cestaMangasCapacidad,cestaMangasCantidad;
    Semaphore cestaCuerposCapacidad,cestaCuerposCantidad;
    FabricanteMangas fabricanteMangas;
    FabricanteCuerpos fabricanteCuerpos;
    MontadorJerseis montadorJerseys;

    public FabricaJerseis(){
        cestaMangasCapacidad = new Semaphore (CAPACIDADMANGAS);
        cestaMangasCantidad = new Semaphore (0);
        cestaCuerposCapacidad = new Semaphore (CAPACIDADCUERPOS);
        cestaCuerposCantidad = new Semaphore (0);
        fabricanteMangas = new FabricanteMangas(cestaMangasCapacidad,cestaMangasCantidad);
        fabricanteCuerpos = new FabricanteCuerpos(cestaCuerposCapacidad,cestaCuerposCantidad);
        montadorJerseys = new MontadorJerseis (cestaMangasCapacidad,cestaMangasCantidad
                ,cestaCuerposCapacidad,cestaCuerposCantidad);
        fin = false;
    }
    public void start(){
        fabricanteMangas.start();
        fabricanteCuerpos.start();
        montadorJerseys.start();
    }
    public void parar(){

        montadorJerseys.parar();
        fabricanteMangas.parar();
        fabricanteCuerpos.parar();

    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        FabricaJerseis ejercicio = new FabricaJerseis();
        ejercicio.start();
        teclado.nextLine();
        ejercicio.parar();


    }
}
