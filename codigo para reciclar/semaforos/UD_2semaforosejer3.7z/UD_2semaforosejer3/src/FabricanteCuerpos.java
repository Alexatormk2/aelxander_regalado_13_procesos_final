import java.util.concurrent.Semaphore;

public class FabricanteCuerpos extends Thread {
    Semaphore cestaCuerposCapacidad, cestaCuerposCantidad;

    public FabricanteCuerpos(Semaphore cestaCuerpos, Semaphore cestaCuerposCantidad) {
        this.cestaCuerposCapacidad = cestaCuerpos;
        this.cestaCuerposCantidad= cestaCuerposCantidad;
    }
    public void run(){
        while (!FabricaJerseis.fin){
            try {

                cestaCuerposCapacidad.acquire();
                //Me aseguro de que aun caben mas cuerpos, fabrico cuerpos
                System.out.println("\t\tFabrico cuerpo");
                cestaCuerposCantidad.release();//YA pueden usar el cuerpo que hemos fabricado
//
            } catch (InterruptedException e) {}
        }
    }
    public void parar() {
        FabricaJerseis.fin = true;
//

    }
}
