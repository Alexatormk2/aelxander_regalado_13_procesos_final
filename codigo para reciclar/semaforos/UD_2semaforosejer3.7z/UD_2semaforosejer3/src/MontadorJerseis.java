import java.util.concurrent.Semaphore;

public class MontadorJerseis extends Thread {
    Semaphore cestaMangasCapacidad;
    Semaphore cestaMangasCantidad;
    Semaphore cestaCuerposCantidad;
    Semaphore cestaCuerposCapacidad;

    public MontadorJerseis(Semaphore cestaMangasCapacidad, Semaphore cestaMangasCantidad,
                           Semaphore cestaCuerposCapacidad, Semaphore cestaCuerposCantidad)
    {
        this.cestaMangasCapacidad = cestaMangasCapacidad;
        this.cestaMangasCantidad = cestaMangasCantidad;
        this.cestaCuerposCantidad= cestaCuerposCantidad;
        this.cestaCuerposCapacidad = cestaCuerposCapacidad;
    }

    public void run(){
        while (!FabricaJerseis.fin){
            try{
                cestaMangasCantidad.acquire(2);
                System.out.println("Tenemos mangas");
                cestaCuerposCantidad.acquire();
                System.out.println("tenemos cuerpos");
                System.out.println ("\t\t\t\tFabrico Jersey");
                cestaMangasCapacidad.release(2);//Libera espacio para nuevas mangas

                cestaCuerposCapacidad.release();//Libera espacio para nuevos cuerpos

            }catch(InterruptedException e){}
        }
    }
    public void parar() {
        FabricaJerseis.fin = true;
    }
}
