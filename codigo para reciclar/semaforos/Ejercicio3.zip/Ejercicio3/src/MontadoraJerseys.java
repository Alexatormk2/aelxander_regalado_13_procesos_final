import java.util.concurrent.Semaphore;

public class MontadoraJerseys extends Thread{

    Semaphore cestaMangasCapacidad;
    Semaphore cestaCuerposCapacidad;

    int CAPACIDADMANGAS;
    int CAPACIDADCUERPOS;

    public MontadoraJerseys(Semaphore cestaMangasCapacidad, Semaphore cestaCuerposCapacidad, int CAPACIDADMANGAS, int CAPACIDADCUERPOS) {
        this.cestaMangasCapacidad = cestaMangasCapacidad;
        this.cestaCuerposCapacidad = cestaCuerposCapacidad;
        this.CAPACIDADMANGAS = CAPACIDADMANGAS;
        this.CAPACIDADCUERPOS = CAPACIDADCUERPOS;
    }

    public void montarJersey() {
        try {
            // Coge 2 mangas si puede
            cestaMangasCapacidad.acquire();
            if (CAPACIDADMANGAS < 2) {
                System.out.println("No hay mangas suficientes para la montadora de jerseys");
            } else {
                System.out.println("Montadora de jerseys coge dos mangas del cesto de mangas");
                CAPACIDADMANGAS = CAPACIDADMANGAS + 2; // Coge dos mangas por lo que la capacidad aumenta en 2
                System.out.println("Caben " + CAPACIDADMANGAS + " más en el cesto de las mangas");
            }
            cestaMangasCapacidad.release();

            // Coge un cuerpo si puede
            cestaCuerposCapacidad.acquire();
            if (CAPACIDADCUERPOS < 1) {
                System.out.println("No hay cuerpos suficientes para la montadora de jerseys");
            } else {
                System.out.println("Montadora de jerseys coge un cuerpo del cesto de cuerpos");
                CAPACIDADCUERPOS++; // Coge un cuerpo por lo que la capacidad aumenta en 1
                System.out.println("Caben " + CAPACIDADCUERPOS + " más en el cesto de las cuerpos");
            }
            cestaCuerposCapacidad.release();

            System.out.println("La montadora de jerseys ha terminado un jersey");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void run() {
        // Repite el metodo montarJersey() para que se pueda parar al pulsar return
        do {
            montarJersey();
        }while (true);

    }
}
