import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {

        final int CAPACIDADMANGAS = 20;
        final int CAPACIDADCUERPOS = 8;
        // static volatile boolean fin;

        // Usamos semáforos binarios porque en este caso lo que hace el fabricante es hacer un if y comprobar si la
        // capacidad es mayor que 0
        Semaphore cestaMangasCapacidad  = new Semaphore(1);
        Semaphore cestaCuerposCapacidad = new Semaphore(1);

        // Otra forma de hacerlo sería hacer otros dos semáforos
        //(Semaphore cestaMangasCantidad  = new Semaphore(CAPACIDADMANGAS)) que actuaría como if

        FabricanteMangas fabricanteMangas = new FabricanteMangas(cestaMangasCapacidad, CAPACIDADMANGAS);
        FabricanteCuerpos fabricanteCuerpos = new FabricanteCuerpos(cestaCuerposCapacidad, CAPACIDADCUERPOS);
        MontadoraJerseys montadoraJerseys = new MontadoraJerseys(cestaMangasCapacidad, cestaCuerposCapacidad, CAPACIDADMANGAS, CAPACIDADCUERPOS);

        fabricanteMangas.start();
        fabricanteCuerpos.start();
        montadoraJerseys.start();
    }
}