import java.util.concurrent.Semaphore;

public class FabricanteMangas extends Thread{

    Semaphore cestaMangasCapacidad;

    int CAPACIDADMANGAS;

    public FabricanteMangas(Semaphore cestaMangasCapacidad, int CAPACIDADMANGAS) {
        this.cestaMangasCapacidad = cestaMangasCapacidad;
        this.CAPACIDADMANGAS = CAPACIDADMANGAS;
    }

    public void fabricarMangas() {
        try {
            cestaMangasCapacidad.acquire();
            System.out.println("Fabricante de mangas está fabricando una manga");
            if(CAPACIDADMANGAS < 1) {
                System.out.println("No entran mas mangas en el cesto");
            } else {
                System.out.println("Fabricante de mangas ha terminado una manga");
                CAPACIDADMANGAS --;
                System.out.println("Caben " + CAPACIDADMANGAS + " más en el cesto de las mangas");
            }

            try {
                sleep((1000));
            } catch (InterruptedException e) {
            }

            cestaMangasCapacidad.release();

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    public void run() {
        // Repite el metodo fabricarMangas() para que se pueda parar al pulsar return
        do {
            fabricarMangas();
        }while (true);
    }
}
