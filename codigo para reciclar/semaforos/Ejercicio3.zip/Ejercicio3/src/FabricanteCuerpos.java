import java.util.concurrent.Semaphore;

public class FabricanteCuerpos extends Thread{

    Semaphore cestaCuerposCapacidad;

    int CAPACIDADCUERPOS;

    public FabricanteCuerpos(Semaphore cestaCuerposCapacidad, int CAPACIDADCUERPOS) {
        this.cestaCuerposCapacidad = cestaCuerposCapacidad;
        this.CAPACIDADCUERPOS = CAPACIDADCUERPOS;
    }

    public void fabricarCuerpos(){
        try {
            cestaCuerposCapacidad.acquire();
            System.out.println("Fabricante de cuerpos está fabricando un cuerpo");
            if(CAPACIDADCUERPOS < 1) {
                System.out.println("No entran mas cuerpos en el cesto");
            } else {
                System.out.println("Fabricante de cuerpos ha terminado un cuerpo");
                CAPACIDADCUERPOS --;
                System.out.println("Caben " + CAPACIDADCUERPOS + " más en el cesto de los cuerpos");
            }

            try {
                sleep((1000));
            } catch (InterruptedException e) {
            }

            cestaCuerposCapacidad.release();

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void run() {
        // Repite el metodo fabricarCuerpos() para que se pueda parar al pulsar return
        do {
            fabricarCuerpos();
        }while (true);
    }
}
