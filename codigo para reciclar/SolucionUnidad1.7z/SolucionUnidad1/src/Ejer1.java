import java.io.IOException;

public class Ejer1 {
    public static void main(String[] args) throws IOException {
        Runtime.getRuntime().exec("notepad");
        Runtime.getRuntime().exec("Notepad.exe notas2.txt");

    }
}
