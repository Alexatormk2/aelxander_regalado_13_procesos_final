/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario1
 */
public class Vehiculo extends Thread{
    int peso;
   
    Puente cruce;

    

    public Vehiculo(int peso, Puente p) {
        this.peso = peso;
       
        this.cruce=p;
    }
    

@Override
    public void run() {
        try {
            System.out.println("Intentando entrar con peso"+ peso);
            cruce.entrarPuente(peso);
            sleep(200);//Tiempo para pasar el puente
            cruce.salirPuente(peso);
        } catch (InterruptedException ex) {
            Logger.getLogger(Vehiculo.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        
    }

}