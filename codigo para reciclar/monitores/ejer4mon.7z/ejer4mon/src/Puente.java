/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usuario1
 */
public class Puente {
    

	private int pesoEnPuente = 0;
	private int nVehiculos   = 0;
	private static final int pesoMaximo = 15000;
	private static final int nVehiculosMaximo = 5;
	
	
	public synchronized void entrarPuente(int Peso) throws InterruptedException {

		
	    
		while(((Peso + pesoEnPuente) > pesoMaximo )||
				((nVehiculos + 1) > nVehiculosMaximo) )
                   {                     
                    wait();
                    System.out.println("Esperando a entrar con peso del vehiculo: "+ Peso+"Peso en puente"+pesoEnPuente);
                }

		
		pesoEnPuente = pesoEnPuente + Peso;
                System.out.println("El peso en este momento es:"+pesoEnPuente);
		nVehiculos++;       
                System.out.println("Coche entra en el puente, hay un total de: "+nVehiculos);
	    notifyAll();
	}

	    
	public synchronized void salirPuente(int Peso) throws InterruptedException {

		pesoEnPuente = pesoEnPuente - Peso;
		nVehiculos--;
                System.out.println("\t\tUn coche sale del puente");
		notifyAll();	    
	}
}
