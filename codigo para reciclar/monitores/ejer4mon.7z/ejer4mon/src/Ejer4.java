/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usuario1
 */
public class Ejer4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Puente cruce= new Puente();
        Vehiculo v1=new Vehiculo(1130,cruce);
        Vehiculo v2=new Vehiculo(1500,cruce);
        Vehiculo v3=new Vehiculo(1330,cruce);
        Vehiculo v4=new Vehiculo(1500,cruce);
        Vehiculo v5=new Vehiculo(5360,cruce);
        Vehiculo v6=new Vehiculo(1453,cruce);
        Vehiculo v7=new Vehiculo(1509,cruce);
        Vehiculo v8=new Vehiculo(1244,cruce);
        Vehiculo v9=new Vehiculo(7121,cruce);
        Vehiculo v10=new Vehiculo(1360,cruce);
        Vehiculo v11=new Vehiculo(1330,cruce);
        Vehiculo v12=new Vehiculo(8350,cruce);
        Vehiculo v13=new Vehiculo(1500,cruce);
        Vehiculo v14=new Vehiculo(1150,cruce);
        Vehiculo v15=new Vehiculo(9432,cruce);
        
        v1.start();
        v2.start();
        v3.start();
        v4.start();
        v5.start();
        v6.start();
        v7.start();
        v8.start();
        v9.start();
        v10.start();
        v11.start();
        v12.start();
        v13.start();
        v14.start();
        v15.start();

        
        
    }
}
