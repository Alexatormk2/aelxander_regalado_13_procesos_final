public class Persona extends Thread {
    Sala s;
    int n;

    public Persona(Sala s, int jubilado){
        this.s=s;
        this.n=jubilado;

    }

    @Override
    public void run() {
        if (n==0) {

            s.entrarSala();

            try {
                this.sleep(800);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("una persona sale de la sala");
            s.salirSala();
        }
        else {
            Thread.currentThread().setPriority(10);
            s.entrarSalaJubilado();

            try {
                this.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("una persona sale de la sala");
            s.salirSalaJubilado();

        }

        }
    }

