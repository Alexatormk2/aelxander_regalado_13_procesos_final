import java.util.Random;

public class ejermuseo {



   public static void main(String[] args){

    Sala s=new Sala();
       Persona p [] = new Persona[60];
       for (int i = 0; i<50; i++){
           Random random = new Random();
           int r = random.nextInt(1);

           p [i] = new Persona(s,r);
       }

       for (int i = 0; i< 50; i++){
           p[i].start();
       }




   }


}
