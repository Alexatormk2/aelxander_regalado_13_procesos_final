public class Persona extends Thread {
    Sala s;

    public Persona(Sala s){
        this.s=s;

    }

    @Override
    public void run() {

        s.entrarSala();

        try {
            this.sleep(800);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("una persona sale de la sala");
        s.salirSala();
    }
}
