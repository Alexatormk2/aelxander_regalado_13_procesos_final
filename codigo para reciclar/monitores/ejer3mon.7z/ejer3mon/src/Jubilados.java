public class Jubilados extends Thread {
    Sala s;

    public Jubilados(Sala s){

        this.s=s;
    }
    @Override
    public void run() {
        s.entrarSalaJubilado();

        try {
            this.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        s.salirSala();
    }
}
