import java.util.Random;

public class temperatura  extends Thread {
    Sala s;
    //boolean fin = false;

    public temperatura(Sala s) {
        this.s = s;
    }

    @Override
    public void run() {
        for (int i = 0; i < 3; i++) {


            Random r = new Random();
            s.notificarTemp(r.nextInt(50));

            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}



