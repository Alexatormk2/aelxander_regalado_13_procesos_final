public class ejer3 {



   public static void main(String[] args){
       Sala s= new Sala();

     /*  Persona p1= new Persona(s);
       Persona p2= new Persona(s);
       Persona p3= new Persona(s);
       Persona p4= new Persona(s);
       Persona p5= new Persona(s);
       Persona p6= new Persona(s);
       Persona p7= new Persona(s);*/
       Persona p [] = new Persona[60];
       for (int i = 0; i<60; i++){
           p [i] = new Persona(s);
       }
       Jubilados j1= new Jubilados(s);
      Jubilados j2= new Jubilados(s);
      temperatura t= new temperatura(s);
       for (int i = 0; i< 50; i++){
           p[i].start();
       }
       j1.setPriority(10);
       j2.setPriority(10);

     /*   p1.start();
        p2.start();
        p3.start();
        p4.start();
        p5.start();
        p6.start();
        p7.start();*/
        t.start();
        j1.start();
        j2.start();


   }


}
