public class Main {

    public static void main(String[] args) {
        RecursoJardin jardin = new RecursoJardin();


        for (int i = 1; i <= 10; i++) {
            (new EntraJardin("Entra" + i, jardin)).start();
        }//entrada de 10 hilos al jardín

        for (int i = 1; i <= 15; i++) {
            (new SaleJardin("Sale" + i, jardin)).start();
        }//salida de 15 hilos al jardín
    }
}
