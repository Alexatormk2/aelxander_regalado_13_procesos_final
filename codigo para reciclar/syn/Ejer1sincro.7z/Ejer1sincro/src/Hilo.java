public class Hilo extends Thread{
    static array sumarray= new array();
    int a[];
    int resp;

    public Hilo(int[] a) {
        this.a = a;
    }

    @Override
    public void run() {
        sumarray.suma(a);
        System.out.println(Thread.currentThread().getName() + "Ha terminado");
    }
}
