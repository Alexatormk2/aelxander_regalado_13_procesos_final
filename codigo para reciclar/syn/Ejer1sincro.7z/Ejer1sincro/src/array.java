public class array {
    private int suma;
    public synchronized void suma(int valores[]){
        suma=0;
        for (int i=0; i<valores.length;i++){
            suma = suma + valores[i];
            System.out.println("Total acumulado de "+Thread.currentThread().getName()+" es "+suma);
            try {
                Thread.sleep(10);//permitir el cambio de tarea
            }catch (InterruptedException exc){
                System.out.println("Hilo interrumpido");
            }
        }




    }
}
