public class principal {
    public static void main(String[] args) {
        int a[] = {1, 2, 3, 4, 5};
        Hilo h=new Hilo(a);
        Hilo h1=new Hilo(a);
        Hilo h2=new Hilo(a);
        Hilo h3=new Hilo(a);
        Hilo h4=new Hilo(a);
        Hilo h5=new Hilo(a);
        h.start();
        h1.start();
        h2.start();
    }





}
