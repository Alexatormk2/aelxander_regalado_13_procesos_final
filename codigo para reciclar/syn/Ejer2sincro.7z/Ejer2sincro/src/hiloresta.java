public class hiloresta extends Thread{
    int num;
    variable v;

    public hiloresta(variable v) {
        this.v = v;
    }

    public hiloresta(int num) {
        this.num = num;
    }


    public hiloresta() {

    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {

//synchronized (v) {
    System.out.println("el valor de la variabel compartida antes de modificar "+v.getNum());
    v.resta();
//}
            System.out.println("El hilo " + Thread.currentThread().getName() + "valor" + v.getNum());
        }
    }

}
