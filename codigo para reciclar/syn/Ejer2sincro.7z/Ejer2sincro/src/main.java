public class main {
    public static void main(String[] args) {
        int num=0;
        variable v = new variable(0);
        hilo h=new hilo(v);
        hilo h1=new hilo(v);
        hilo h2=new hilo(v);
        hilo h3=new hilo(v);
        hilo h4=new hilo(v);
        hilo h5=new hilo(v);
        hiloresta hr=new hiloresta(v);
        hiloresta hr1=new hiloresta(v);
        h.start();
        h1.start();
        h2.start();
        h3.start();
        h4.start();
        h5.start();
        hr.start();
        hr1.start();


    }
}
