public class hilo extends Thread{
    int num;
variable v;

    public hilo(variable v) {
        this.v = v;
    }

    public hilo(int num) {
        this.num = num;
    }


    public hilo() {

    }

    @Override
    public void run() {

        for (int i = 0; i < 10; i++) {
//podemos sincronizar el propio objeto
//synchronized (v) {
    v.obtenervalor();
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            v.suma();
//}
            System.out.println("El hilo " + Thread.currentThread().getName() + "valor" + v.getNum());
        }
    }
}
