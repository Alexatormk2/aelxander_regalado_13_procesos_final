public class variable {
    int num;

    public variable(int num) {
        this.num = num;
    }
    public  synchronized void suma(){
        num=num+1;

    }
    public synchronized void resta(){

        num=num-1;
    }
public void obtenervalor(){
    System.out.println("el valor de la variabel compartida antes de modificar "+num);

}
    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
